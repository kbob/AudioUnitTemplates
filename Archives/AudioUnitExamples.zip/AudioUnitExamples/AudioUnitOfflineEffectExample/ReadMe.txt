ReadMe for ReverseOfflineUnit
-----------------------------

ReverseOfflineUnit project demonstrates how to build a simple Offline Effect Audio Unit. It assumes that its input and output sample formats are same and does not do any conversion. 

Sample Requirements
-------------------
This sample project requires:
	
	Mac OS X v10.9 or later
	Xcode 5.0 or later
	
Feedback
--------
To send feedback to Apple about this sample project, use the feedback form at 
this location:

	http://developer.apple.com/contact/

Copyright (C) 2013 Apple Inc. All rights reserved.